import unittest
from dikwp_sail.core import *

class CoreTests(unittest.TestCase):
    def test_kinds(self): self.assertEqual(CORE_KINDS,("D","I","K","W","P"))
    def test_routes(self): self.assertEqual(len(ROUTES),25)
    def test_empty_explicit(self): self.assertEqual(packet_not_given(empty_packet()),list(CORE_KINDS))
    def test_missing_rejected(self):
        with self.assertRaises(SemanticSpecError): normalize_packet({})
    def test_extra_rejected(self):
        with self.assertRaises(SemanticSpecError): normalize_packet({**empty_packet(),"X":{}})
    def test_false_with_content_rejected(self):
        p=empty_packet();p["D"]={"given":False,"same_semantics":["x"]}
        with self.assertRaises(SemanticSpecError): normalize_packet(p)
    def test_source_open(self):
        _,e=apply_route(empty_packet(),{"from":"D","to":"I","target_part":{"given":True,"different_semantics":["x"]}})
        self.assertEqual(e["state"],"OPEN_SOURCE_NOT_GIVEN")
    def test_target_open(self):
        p=empty_packet();p["D"]={"given":True,"same_semantics":["x"]}
        _,e=apply_route(p,{"from":"D","to":"I"});self.assertEqual(e["state"],"OPEN_TARGET_NOT_EXPLICIT")
