import unittest
from dikwp_sail.conformance import run_conformance

class ConformanceTests(unittest.TestCase):
    def test_all(self):
        r=run_conformance();self.assertTrue(r["all_obligations_observed"]);self.assertIsNone(r["aggregate_score"]);self.assertEqual(len(r["checks"]),35)
