import unittest
from dikwp_sail.adapters import wrap
from dikwp_sail.core import empty_packet
from dikwp_sail.passport import validate_passport

class AdapterTests(unittest.TestCase):
    def test_mcp(self):
        p=wrap("mcp",{"jsonrpc":"2.0","method":"tools/list"},issuer="i",subject="s",packet=empty_packet())
        self.assertTrue(validate_passport(p)["valid"]);self.assertEqual(p["adapter_view"]["method"],"tools/list")
    def test_mcp_version(self):
        with self.assertRaises(ValueError): wrap("mcp",{"jsonrpc":"1.0"},issuer="i",subject="s",packet=empty_packet())
    def test_a2a(self): self.assertEqual(wrap("a2a",{"messageId":"m"},issuer="i",subject="s",packet=empty_packet())["adapter_view"]["message_id"],"m")
    def test_openai(self): self.assertEqual(wrap("openai",{"id":"r","output":[]},issuer="i",subject="s",packet=empty_packet())["adapter_view"]["response_id"],"r")
    def test_generic(self): self.assertEqual(wrap("generic",{"x":1},issuer="i",subject="s",packet=empty_packet())["carrier"]["semantic_authority"],0)
