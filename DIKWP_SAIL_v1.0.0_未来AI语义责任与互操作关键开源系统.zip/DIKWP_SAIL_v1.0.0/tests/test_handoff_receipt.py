import unittest
from dikwp_sail.passport import create_passport
from dikwp_sail.handoff import create_handoff
from dikwp_sail.demos import full_packet
from dikwp_sail.core import empty_packet
from dikwp_sail.receipt import verify_receipt
from dikwp_sail.demos import demo_mcp_ready

class HandoffReceiptTests(unittest.TestCase):
    def test_no_copy(self):
        s=create_passport(full_packet(),issuer="a",subject="s",carrier_protocol="a2a")
        h=create_handoff(s,receiver_subject="s",receiver_issuer="b")
        self.assertEqual(h["copy_policy"],"NO_AUTOMATIC_CORE_COPY")
        self.assertFalse(h["receiver_passport"]["semantic_packet"]["W"]["given"])
        self.assertFalse(h["receiver_passport"]["semantic_packet"]["P"]["given"])
    def test_difference(self):
        s=create_passport(full_packet(),issuer="a",subject="s",carrier_protocol="a2a")
        h=create_handoff(s,receiver_subject="s",receiver_issuer="b",receiver_packet=empty_packet())
        self.assertEqual(h["relation_vector"]["W"],"SENDER_EXPLICIT_RECEIVER_OPEN")
    def test_receipt(self): self.assertTrue(verify_receipt(demo_mcp_ready()["receipt"])["valid"])
    def test_tampered_receipt(self):
        r=demo_mcp_ready()["receipt"];r["gate_state"]="changed"
        self.assertFalse(verify_receipt(r)["valid"])
