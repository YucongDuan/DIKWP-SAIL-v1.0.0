import unittest
from dikwp_sail.registry import AliasRegistry
from dikwp_sail.demos import full_packet, demo_mcp_ready
from dikwp_sail.observability import otel_attributes, export_otlp_json
from dikwp_sail.provenance import to_prov_jsonld

class RegistryObservabilityTests(unittest.TestCase):
    def test_registry(self):
        r=AliasRegistry();r.register("invoice",full_packet(),actor="human")
        self.assertEqual(r.aliases_for_packet(full_packet()),["invoice"])
    def test_revision(self):
        r=AliasRegistry();r.register("invoice",full_packet(),actor="human");r.register("invoice",full_packet(),actor="human")
        self.assertEqual(r.record("invoice")["revision"],2)
    def test_otel(self):
        run=demo_mcp_ready();attrs=otel_attributes(run["passport"],run["gate"])
        self.assertEqual(attrs["dikwp.sail.semantic_authority"],0)
        self.assertIn("resourceSpans",export_otlp_json([run["otel_span"]]))
    def test_prov(self):
        run=demo_mcp_ready();prov=to_prov_jsonld(run["passport"],activity_id="x",actor_id="a",gate_result=run["gate"])
        self.assertEqual(prov["semantic_authority"],0)
