import unittest
from dikwp_sail import SAILRuntime, create_grant
from dikwp_sail.demos import full_packet, partial_packet

class GateTests(unittest.TestCase):
    def setUp(self): self.runtime=SAILRuntime()
    def test_ready_action(self):
        p=self.runtime.wrap("generic",{},issuer="i",subject="s",packet=full_packet())
        g=create_grant(actor="a",subject="s",kinds=["W","P"],operations=["action.request"])
        r=self.runtime.prepare_action(p,{"actor":"a","subject":"s"},grants=[g])
        self.assertEqual(r["gate"]["state"],"READY_FOR_CALLER_EXECUTION");self.assertFalse(r["executed"])
    def test_open_w(self):
        p=self.runtime.wrap("generic",{},issuer="i",subject="s",packet=partial_packet())
        g=create_grant(actor="a",subject="s",kinds=["P"],operations=["action.request"])
        r=self.runtime.prepare_action(p,{"actor":"a","subject":"s"},grants=[g])
        self.assertEqual(r["gate"]["state"],"OPEN_SEMANTIC_OBLIGATIONS")
    def test_open_authority(self):
        p=self.runtime.wrap("generic",{},issuer="i",subject="s",packet=full_packet())
        r=self.runtime.prepare_action(p,{"actor":"a","subject":"s"},grants=[])
        self.assertEqual(r["gate"]["state"],"OPEN_SEMANTIC_OBLIGATIONS")
    def test_exact_output(self):
        p=self.runtime.wrap("generic",{},issuer="i",subject="s",packet=full_packet())
        g=create_grant(actor="a",subject="s",kinds=["W","P"],operations=["action.request"])
        r=self.runtime.prepare_action(p,{"actor":"a","subject":"s","expected_purpose_output":{"x":1}},grants=[g])
        self.assertEqual(r["gate"]["vector"]["purpose_output_match"],"OPEN_NO_EXACT_MATCH")
    def test_memory_scope(self):
        p=self.runtime.wrap("generic",{},issuer="i",subject="s",packet=full_packet())
        g=create_grant(actor="a",subject="s",kinds=["P"],operations=["memory.write"])
        r=self.runtime.prepare_memory(p,{"actor":"a","subject":"s"},grants=[g])
        self.assertEqual(r["gate"]["vector"]["retention_scope"],"OPEN_NOT_EXPLICIT");self.assertFalse(r["written"])
