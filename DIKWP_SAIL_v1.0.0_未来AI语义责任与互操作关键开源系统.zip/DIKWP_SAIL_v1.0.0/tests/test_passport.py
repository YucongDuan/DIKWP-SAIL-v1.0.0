import unittest
from dikwp_sail.passport import *
from dikwp_sail.demos import full_packet
from dikwp_sail.core import CORE_KINDS

class PassportTests(unittest.TestCase):
    def test_valid(self): self.assertTrue(validate_passport(create_passport(full_packet(),issuer="i",subject="s",carrier_protocol="generic"))["valid"])
    def test_scaffold(self): self.assertEqual(scaffold_passport({"text":"x"},issuer="i",subject="s",carrier_protocol="generic")["not_given"],list(CORE_KINDS))
    def test_deterministic_id(self):
        a=create_passport(full_packet(),issuer="i",subject="s",carrier_protocol="generic",carrier_payload={"x":1})
        b=create_passport(full_packet(),issuer="i",subject="s",carrier_protocol="generic",carrier_payload={"x":1})
        self.assertEqual(a["passport_id"],b["passport_id"])
    def test_tamper(self):
        p=create_passport(full_packet(),issuer="i",subject="s",carrier_protocol="generic");p["subject"]="changed"
        self.assertFalse(validate_passport(p)["valid"])
