# Changelog

## 1.0.0 - 2026-08-06

- First public reference release.
- Semantic Passport 1.0.
- MESH8.0 five-core and 25-route runtime.
- MCP, A2A, OpenAI-shaped and generic adapters.
- Action and memory W/P responsibility gates.
- Handoff preservation, receipts, replay, OTLP-shaped and PROV-O-shaped exports.
- Conformance TCK, local gateway, wheel, PYZ and source archive.
