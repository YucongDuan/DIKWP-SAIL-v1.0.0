from __future__ import annotations

from copy import deepcopy
from typing import Any

from .core import CORE_KINDS, empty_packet, exact_value_match, normalize_packet, packet_digest
from .passport import create_passport, validate_passport
from .integrity import digest, utc_now


def _kind_relation(sender: dict[str, Any], receiver: dict[str, Any], kind: str) -> str:
    left = sender[kind]
    right = receiver[kind]
    if not left["given"] and not right["given"]:
        return "BOTH_OPEN_NOT_GIVEN"
    if left["given"] and not right["given"]:
        return "SENDER_EXPLICIT_RECEIVER_OPEN"
    if not left["given"] and right["given"]:
        return "SENDER_OPEN_RECEIVER_EXPLICIT"
    return "EXACT_EXPLICIT_MATCH" if exact_value_match(left, right) else "EXPLICIT_DIFFERENCE_PRESERVED"


def create_handoff(
    sender_passport: Any,
    *,
    receiver_subject: str,
    receiver_issuer: str,
    receiver_packet: Any | None = None,
    shared_packet: Any | None = None,
    carrier_protocol: str = "a2a",
    carrier_payload: Any = None,
) -> dict[str, Any]:
    sender_validation = validate_passport(sender_passport)
    if not sender_validation["valid"]:
        raise ValueError(f"sender passport is not valid: {sender_validation['errors']}")
    sender_packet = normalize_packet(sender_passport["semantic_packet"])
    receiver_norm = normalize_packet(receiver_packet if receiver_packet is not None else empty_packet())
    receiver_passport = create_passport(
        receiver_norm,
        issuer=receiver_issuer,
        subject=receiver_subject,
        carrier_protocol=carrier_protocol,
        carrier_payload=carrier_payload,
        lineage=[sender_passport["passport_id"]],
        profile="handoff-receiver",
    )
    shared_norm = normalize_packet(shared_packet) if shared_packet is not None else None
    relation = {kind: _kind_relation(sender_packet, receiver_norm, kind) for kind in CORE_KINDS}
    body = {
        "spec": "dikwp-sail-handoff/1.0",
        "sender_passport_id": sender_passport["passport_id"],
        "receiver_passport": receiver_passport,
        "shared_packet": deepcopy(shared_norm),
        "relation_vector": relation,
        "copy_policy": "NO_AUTOMATIC_CORE_COPY",
        "w_p_inheritance": "EXPLICIT_ONLY",
        "carrier_semantic_authority": 0,
    }
    return {
        "handoff_id": "handoff_" + digest(body)[:24],
        "created_at": utc_now(),
        **body,
    }


def handoff_packet_digests(handoff: Any) -> dict[str, Any]:
    if not isinstance(handoff, dict):
        raise ValueError("handoff must be an object")
    receiver = handoff["receiver_passport"]["semantic_packet"]
    shared = handoff.get("shared_packet")
    return {
        "receiver": packet_digest(receiver),
        "shared": packet_digest(shared) if shared is not None else None,
    }
