from __future__ import annotations

from copy import deepcopy
from typing import Any

from .authority import authority_vector
from .core import CORE_KINDS, exact_value_match, normalize_packet
from .passport import validate_passport

POLICY_PROFILES: dict[str, dict[str, Any]] = {
    "observe": {
        "required_kinds": ["D", "I"],
        "authority_kinds": [],
        "operation": "semantic.read",
    },
    "act": {
        "required_kinds": ["W", "P"],
        "authority_kinds": ["W", "P"],
        "operation": "action.request",
    },
    "persist": {
        "required_kinds": ["P"],
        "authority_kinds": ["P"],
        "operation": "memory.write",
    },
    "high-impact": {
        "required_kinds": ["D", "I", "K", "W", "P"],
        "authority_kinds": ["W", "P"],
        "operation": "action.request",
    },
}


def _gate(
    passport: Any,
    request: Any,
    grants: list[dict[str, Any]] | None,
    *,
    profile: str,
) -> dict[str, Any]:
    if profile not in POLICY_PROFILES:
        raise ValueError(f"unknown policy profile: {profile}")
    policy = POLICY_PROFILES[profile]
    validation = validate_passport(passport)
    packet = normalize_packet(passport.get("semantic_packet") if isinstance(passport, dict) else None)
    if not isinstance(request, dict):
        raise ValueError("request must be an object")
    actor = str(request.get("actor", "")).strip()
    subject = str(request.get("subject", "")).strip()
    if not actor or not subject:
        raise ValueError("request.actor and request.subject must be non-empty")

    vector: dict[str, Any] = {
        "passport_integrity": "OBSERVED" if validation["valid"] else "OPEN_PASSPORT_INTEGRITY",
        "requested_profile": profile,
        "required_kinds": {},
        "authority": {},
        "purpose_output_match": "NOT_REQUESTED",
        "external_execution_authority": 0,
    }
    reasons: list[str] = list(validation.get("errors", []))
    for kind in policy["required_kinds"]:
        if packet[kind]["given"]:
            vector["required_kinds"][kind] = "EXPLICIT"
        else:
            vector["required_kinds"][kind] = "OPEN_NOT_GIVEN"
            reasons.append(f"{kind} is not given")

    auth = authority_vector(
        list(grants or []),
        actor=actor,
        subject=subject,
        operation=policy["operation"],
        required_kinds=list(policy["authority_kinds"]),
    )
    vector["authority"] = auth["vector"]
    for kind, state in auth["vector"].items():
        if state != "EXPLICIT_AUTHORITY":
            reasons.append(f"{kind} authority remains open")

    expected_output = request.get("expected_purpose_output")
    if expected_output is not None:
        if packet["P"]["given"] and exact_value_match(packet["P"]["output"], expected_output):
            vector["purpose_output_match"] = "EXACT_EXPLICIT_MATCH"
        else:
            vector["purpose_output_match"] = "OPEN_NO_EXACT_MATCH"
            reasons.append("request does not exactly match explicit P.output")

    ready = (
        validation["valid"]
        and all(state == "EXPLICIT" for state in vector["required_kinds"].values())
        and all(state == "EXPLICIT_AUTHORITY" for state in vector["authority"].values())
        and vector["purpose_output_match"] in {"NOT_REQUESTED", "EXACT_EXPLICIT_MATCH"}
    )
    return {
        "state": "READY_FOR_CALLER_EXECUTION" if ready else "OPEN_SEMANTIC_OBLIGATIONS",
        "profile": profile,
        "operation": policy["operation"],
        "vector": vector,
        "reasons": reasons,
        "request": deepcopy(request),
        "automatic_execution": False,
        "semantic_authority": 0,
    }


def gate_action(
    passport: Any,
    request: Any,
    grants: list[dict[str, Any]] | None = None,
    *,
    profile: str = "act",
) -> dict[str, Any]:
    if profile not in {"act", "high-impact"}:
        raise ValueError("action gate profile must be act or high-impact")
    return _gate(passport, request, grants, profile=profile)


def gate_memory(
    passport: Any,
    request: Any,
    grants: list[dict[str, Any]] | None = None,
    *,
    profile: str = "persist",
) -> dict[str, Any]:
    if profile != "persist":
        raise ValueError("memory gate profile must be persist")
    result = _gate(passport, request, grants, profile=profile)
    retention_scope = request.get("retention_scope") if isinstance(request, dict) else None
    if retention_scope is None:
        result["vector"]["retention_scope"] = "OPEN_NOT_EXPLICIT"
        result["reasons"].append("retention_scope is not explicit")
        result["state"] = "OPEN_SEMANTIC_OBLIGATIONS"
    else:
        result["vector"]["retention_scope"] = "EXPLICIT"
    return result


def nonaggregate_gate_vector(result: Any) -> dict[str, Any]:
    if not isinstance(result, dict):
        raise ValueError("gate result must be an object")
    return deepcopy(result.get("vector", {}))
