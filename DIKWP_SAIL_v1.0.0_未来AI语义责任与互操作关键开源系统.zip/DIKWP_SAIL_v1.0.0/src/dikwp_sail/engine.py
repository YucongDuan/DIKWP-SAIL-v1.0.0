from __future__ import annotations

from copy import deepcopy
from typing import Any

from .adapters import wrap
from .gate import gate_action, gate_memory
from .observability import make_span
from .provenance import to_prov_jsonld
from .receipt import create_receipt


class SAILRuntime:
    """Protocol-neutral semantic accountability runtime.

    It prepares packets, gate vectors and receipts. It never executes tools,
    writes memory, or assigns external truth on its own.
    """

    def wrap(
        self,
        protocol: str,
        payload: Any,
        *,
        issuer: str,
        subject: str,
        packet: Any | None = None,
        aliases: list[str] | None = None,
    ) -> dict[str, Any]:
        return wrap(
            protocol,
            payload,
            issuer=issuer,
            subject=subject,
            packet=packet,
            aliases=aliases,
        )

    def prepare_action(
        self,
        passport: Any,
        request: Any,
        *,
        grants: list[dict[str, Any]] | None = None,
        profile: str = "act",
        external_result: Any = None,
        secret: str | None = None,
    ) -> dict[str, Any]:
        gate = gate_action(passport, request, grants, profile=profile)
        receipt = create_receipt(
            passport=passport,
            operation_request=request,
            gate_result=gate,
            external_result=external_result,
            secret=secret,
        )
        return {
            "passport": deepcopy(passport),
            "gate": gate,
            "receipt": receipt,
            "otel_span": make_span(passport, name="dikwp.sail.action", gate_result=gate),
            "provenance": to_prov_jsonld(
                passport,
                activity_id=receipt["receipt_id"],
                actor_id=str(request.get("actor", "unknown")),
                gate_result=gate,
            ),
            "executed": False,
        }

    def prepare_memory(
        self,
        passport: Any,
        request: Any,
        *,
        grants: list[dict[str, Any]] | None = None,
        external_result: Any = None,
        secret: str | None = None,
    ) -> dict[str, Any]:
        gate = gate_memory(passport, request, grants)
        receipt = create_receipt(
            passport=passport,
            operation_request=request,
            gate_result=gate,
            external_result=external_result,
            secret=secret,
        )
        return {
            "passport": deepcopy(passport),
            "gate": gate,
            "receipt": receipt,
            "otel_span": make_span(passport, name="dikwp.sail.memory", gate_result=gate),
            "provenance": to_prov_jsonld(
                passport,
                activity_id=receipt["receipt_id"],
                actor_id=str(request.get("actor", "unknown")),
                gate_result=gate,
            ),
            "written": False,
        }
