from __future__ import annotations

from copy import deepcopy
from typing import Any


def to_prov_jsonld(
    passport: Any,
    *,
    activity_id: str,
    actor_id: str,
    gate_result: Any | None = None,
) -> dict[str, Any]:
    if not isinstance(passport, dict):
        raise ValueError("passport must be an object")
    pid = str(passport.get("passport_id"))
    activity = f"urn:dikwp-sail:activity:{activity_id}"
    actor = f"urn:dikwp-sail:agent:{actor_id}"
    entity = f"urn:dikwp-sail:passport:{pid}"
    graph: list[dict[str, Any]] = [
        {
            "@id": entity,
            "@type": "prov:Entity",
            "dikwp:semanticDigest": passport.get("semantic_digest"),
            "dikwp:carrierProtocol": passport.get("carrier", {}).get("protocol"),
            "dikwp:semanticAuthority": 0,
        },
        {"@id": actor, "@type": "prov:Agent"},
        {
            "@id": activity,
            "@type": "prov:Activity",
            "prov:used": {"@id": entity},
            "prov:wasAssociatedWith": {"@id": actor},
            "dikwp:executionPerformed": False,
        },
    ]
    if isinstance(gate_result, dict):
        graph[-1]["dikwp:gateState"] = gate_result.get("state")
        graph[-1]["dikwp:gateVector"] = deepcopy(gate_result.get("vector"))
    return {
        "@context": {
            "prov": "http://www.w3.org/ns/prov#",
            "dikwp": "https://w3id.org/dikwp/sail#",
        },
        "@graph": graph,
        "semantic_authority": 0,
    }
