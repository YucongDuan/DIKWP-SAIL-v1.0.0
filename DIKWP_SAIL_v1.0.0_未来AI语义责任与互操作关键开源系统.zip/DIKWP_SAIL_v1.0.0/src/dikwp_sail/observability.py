from __future__ import annotations

from copy import deepcopy
from typing import Any

from .core import CORE_KINDS
from .integrity import digest, utc_now


def otel_attributes(passport: Any, gate_result: Any | None = None) -> dict[str, Any]:
    if not isinstance(passport, dict):
        raise ValueError("passport must be an object")
    packet = passport.get("semantic_packet", {})
    attrs: dict[str, Any] = {
        "dikwp.sail.spec": passport.get("spec"),
        "dikwp.sail.passport.id": passport.get("passport_id"),
        "dikwp.sail.semantic.digest": passport.get("semantic_digest"),
        "dikwp.sail.carrier.protocol": passport.get("carrier", {}).get("protocol"),
        "dikwp.sail.semantic_authority": 0,
    }
    for kind in CORE_KINDS:
        attrs[f"dikwp.sail.given.{kind.lower()}"] = bool(packet.get(kind, {}).get("given"))
    if isinstance(gate_result, dict):
        attrs["dikwp.sail.gate.state"] = gate_result.get("state")
        attrs["dikwp.sail.gate.profile"] = gate_result.get("profile")
        attrs["dikwp.sail.execution.performed"] = False
    return attrs


def make_span(passport: Any, *, name: str, gate_result: Any | None = None) -> dict[str, Any]:
    body = {
        "name": str(name),
        "start_time": utc_now(),
        "end_time": utc_now(),
        "attributes": otel_attributes(passport, gate_result),
        "semantic_authority": 0,
    }
    return {"span_id": digest(body)[:16], **body}


def export_otlp_json(spans: list[dict[str, Any]]) -> dict[str, Any]:
    """Dependency-free OTLP-shaped JSON for downstream translation."""
    return {
        "resourceSpans": [
            {
                "resource": {"attributes": [{"key": "service.name", "value": {"stringValue": "dikwp-sail"}}]},
                "scopeSpans": [{"scope": {"name": "dikwp-sail"}, "spans": deepcopy(spans)}],
            }
        ],
        "semantic_authority": 0,
    }
