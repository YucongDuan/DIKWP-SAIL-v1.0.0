from __future__ import annotations

from copy import deepcopy
from typing import Any

from .core import CORE_KINDS
from .integrity import digest, utc_now

OPERATIONS = (
    "semantic.read",
    "semantic.write",
    "action.request",
    "memory.write",
    "handoff.send",
    "handoff.receive",
    "shared.publish",
)


def create_grant(
    *,
    actor: str,
    subject: str,
    kinds: list[str],
    operations: list[str],
    scope: str = "local",
    authority_source: str = "explicit",
) -> dict[str, Any]:
    actor = str(actor).strip()
    subject = str(subject).strip()
    if not actor or not subject:
        raise ValueError("actor and subject must be non-empty")
    normalized_kinds = sorted(set(str(k) for k in kinds))
    if any(kind not in CORE_KINDS for kind in normalized_kinds):
        raise ValueError("grant kinds must be D, I, K, W, or P")
    normalized_ops = sorted(set(str(op) for op in operations))
    if any(op not in OPERATIONS for op in normalized_ops):
        raise ValueError(f"unsupported operation in {normalized_ops}")
    body = {
        "actor": actor,
        "subject": subject,
        "kinds": normalized_kinds,
        "operations": normalized_ops,
        "scope": str(scope),
        "authority_source": str(authority_source),
        "semantic_authority": 0,
    }
    return {
        "grant_id": "grant_" + digest(body)[:24],
        "created_at": utc_now(),
        **body,
    }


def validate_grant(raw: Any) -> bool:
    if not isinstance(raw, dict):
        return False
    try:
        expected = create_grant(
            actor=raw["actor"],
            subject=raw["subject"],
            kinds=list(raw["kinds"]),
            operations=list(raw["operations"]),
            scope=raw.get("scope", "local"),
            authority_source=raw.get("authority_source", "explicit"),
        )
    except Exception:
        return False
    return raw.get("grant_id") == expected["grant_id"]


def authority_vector(
    grants: list[dict[str, Any]],
    *,
    actor: str,
    subject: str,
    operation: str,
    required_kinds: list[str],
) -> dict[str, Any]:
    vector: dict[str, str] = {}
    matched: dict[str, list[str]] = {}
    for kind in required_kinds:
        grant_ids: list[str] = []
        for grant in grants:
            if not validate_grant(grant):
                continue
            if (
                grant.get("actor") == actor
                and grant.get("subject") == subject
                and operation in grant.get("operations", [])
                and kind in grant.get("kinds", [])
            ):
                grant_ids.append(str(grant.get("grant_id")))
        vector[kind] = "EXPLICIT_AUTHORITY" if grant_ids else "OPEN_AUTHORITY"
        matched[kind] = grant_ids
    return {"vector": vector, "matched_grants": deepcopy(matched)}
