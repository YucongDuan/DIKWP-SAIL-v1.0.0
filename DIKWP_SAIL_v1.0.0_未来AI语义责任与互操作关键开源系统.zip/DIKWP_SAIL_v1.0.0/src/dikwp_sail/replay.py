from __future__ import annotations

from typing import Any

from .passport import validate_passport
from .receipt import verify_receipt


def replay(passport: Any, receipt: Any | None = None, *, secret: str | None = None) -> dict[str, Any]:
    passport_result = validate_passport(passport)
    receipt_result = verify_receipt(receipt, secret=secret) if receipt is not None else None
    return {
        "passport": passport_result,
        "receipt": receipt_result,
        "deterministic_replay": (
            passport_result["valid"]
            and (receipt_result is None or receipt_result["valid"])
        ),
        "semantic_authority": 0,
    }
