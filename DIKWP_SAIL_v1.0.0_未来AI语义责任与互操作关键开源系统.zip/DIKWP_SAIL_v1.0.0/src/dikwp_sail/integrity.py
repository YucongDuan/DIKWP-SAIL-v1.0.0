from __future__ import annotations

import hashlib
import hmac
import json
from copy import deepcopy
from datetime import datetime, timezone
from typing import Any


def canonical_bytes(value: Any) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")


def digest(value: Any) -> str:
    return hashlib.sha256(canonical_bytes(value)).hexdigest()


def utc_now() -> str:
    return (
        datetime.now(timezone.utc)
        .replace(microsecond=0)
        .isoformat()
        .replace("+00:00", "Z")
    )


def make_ledger(events: list[dict[str, Any]]) -> dict[str, Any]:
    previous = "0" * 64
    rows: list[dict[str, Any]] = []
    for index, event in enumerate(events):
        payload = {"index": index, "previous": previous, "event": deepcopy(event)}
        row_hash = digest(payload)
        rows.append({**payload, "hash": row_hash})
        previous = row_hash
    return {
        "algorithm": "SHA-256",
        "semantic_authority": 0,
        "genesis": "0" * 64,
        "events": rows,
        "head": previous,
    }


def verify_ledger(ledger: Any) -> dict[str, Any]:
    if not isinstance(ledger, dict):
        return {"valid": False, "error": "ledger must be an object"}
    rows = ledger.get("events", [])
    if not isinstance(rows, list):
        return {"valid": False, "error": "ledger.events must be a list"}
    previous = ledger.get("genesis", "")
    valid = previous == "0" * 64
    for expected_index, row in enumerate(rows):
        if not isinstance(row, dict):
            valid = False
            break
        payload = {
            "index": row.get("index"),
            "previous": row.get("previous"),
            "event": row.get("event"),
        }
        if (
            row.get("index") != expected_index
            or row.get("previous") != previous
            or row.get("hash") != digest(payload)
        ):
            valid = False
            break
        previous = row.get("hash")
    head_ok = previous == ledger.get("head")
    return {"valid": valid and head_ok, "rows_valid": valid, "head_valid": head_ok}


def hmac_sign(value: Any, secret: str) -> str:
    if not isinstance(secret, str) or not secret:
        raise ValueError("secret must be a non-empty string")
    return hmac.new(secret.encode("utf-8"), canonical_bytes(value), hashlib.sha256).hexdigest()


def hmac_verify(value: Any, secret: str, signature: str) -> bool:
    expected = hmac_sign(value, secret)
    return hmac.compare_digest(expected, str(signature))
