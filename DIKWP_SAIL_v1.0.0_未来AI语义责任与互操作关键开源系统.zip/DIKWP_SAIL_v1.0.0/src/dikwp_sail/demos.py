from __future__ import annotations

from copy import deepcopy
from pathlib import Path
from typing import Any

from .authority import create_grant
from .core import empty_packet
from .dashboard import render_dashboard
from .engine import SAILRuntime
from .handoff import create_handoff
from .integrity import canonical_bytes


def full_packet() -> dict[str, Any]:
    return {
        "D": {"given": True, "same_semantics": ["user-approved invoice total 125.00"]},
        "I": {"given": True, "different_semantics": ["currency=USD", "vendor=Example Co"]},
        "K": {"given": True, "complete_semantics": ["approved invoice payment request for Example Co"]},
        "W": {"given": True, "value_information": ["do not exceed approved amount", "preserve audit trail"]},
        "P": {"given": True, "input": "approved invoice", "output": {"tool": "payments.schedule", "amount": 125.0, "currency": "USD"}},
    }


def partial_packet() -> dict[str, Any]:
    packet = full_packet()
    packet["W"] = {"given": False, "value_information": []}
    return packet


def demo_mcp_ready() -> dict[str, Any]:
    runtime = SAILRuntime()
    payload = {"jsonrpc": "2.0", "id": 7, "method": "tools/call", "params": {"name": "payments.schedule", "arguments": {"amount": 125.0, "currency": "USD"}}}
    passport = runtime.wrap("mcp", payload, issuer="human:owner", subject="invoice:42", packet=full_packet(), aliases=["approved payment"])
    grants = [create_grant(actor="agent:payable", subject="invoice:42", kinds=["W", "P"], operations=["action.request"])]
    request = {"actor": "agent:payable", "subject": "invoice:42", "expected_purpose_output": {"tool": "payments.schedule", "amount": 125.0, "currency": "USD"}}
    return runtime.prepare_action(passport, request, grants=grants)


def demo_mcp_open_w() -> dict[str, Any]:
    runtime = SAILRuntime()
    payload = {"jsonrpc": "2.0", "id": 8, "method": "tools/call", "params": {"name": "payments.schedule"}}
    passport = runtime.wrap("mcp", payload, issuer="model:planner", subject="invoice:43", packet=partial_packet())
    grants = [create_grant(actor="agent:payable", subject="invoice:43", kinds=["P"], operations=["action.request"])]
    request = {"actor": "agent:payable", "subject": "invoice:43", "expected_purpose_output": full_packet()["P"]["output"]}
    return runtime.prepare_action(passport, request, grants=grants)


def demo_a2a_handoff() -> dict[str, Any]:
    runtime = SAILRuntime()
    sender = runtime.wrap("a2a", {"messageId": "m-1", "role": "agent", "parts": [{"text": "handoff"}]}, issuer="agent:planner", subject="task:alpha", packet=full_packet())
    receiver = empty_packet()
    receiver["D"] = {"given": True, "same_semantics": ["task alpha received"]}
    receiver["I"] = {"given": True, "different_semantics": ["receiver has no payment authority"]}
    return create_handoff(sender, receiver_subject="task:alpha", receiver_issuer="agent:executor", receiver_packet=receiver, carrier_payload={"taskId": "alpha"})


def demo_openai_tool_call() -> dict[str, Any]:
    runtime = SAILRuntime()
    payload = {"id": "resp_1", "object": "response", "model": "example-model", "output": [{"type": "function_call", "name": "payments.schedule", "arguments": "{\"amount\":125}"}]}
    return runtime.wrap("openai", payload, issuer="model:example", subject="invoice:42", packet=full_packet())


def demo_memory_ready() -> dict[str, Any]:
    runtime = SAILRuntime()
    passport = runtime.wrap("generic", {"memory": "customer preference"}, issuer="human:owner", subject="profile:7", packet=full_packet())
    grants = [create_grant(actor="agent:memory", subject="profile:7", kinds=["P"], operations=["memory.write"])]
    request = {"actor": "agent:memory", "subject": "profile:7", "retention_scope": {"duration": "session", "audience": ["profile:7"]}}
    return runtime.prepare_memory(passport, request, grants=grants)


def demo_scaffold_no_inference() -> dict[str, Any]:
    runtime = SAILRuntime()
    return runtime.wrap("generic", {"text": "The carrier contains words, but no DIKWP content was explicitly supplied."}, issuer="carrier:demo", subject="demo:scaffold", packet=None)

DEMOS = {
    "mcp_ready": demo_mcp_ready,
    "mcp_open_w": demo_mcp_open_w,
    "a2a_handoff": demo_a2a_handoff,
    "openai_tool_call": demo_openai_tool_call,
    "memory_ready": demo_memory_ready,
    "scaffold_no_inference": demo_scaffold_no_inference,
}


def run_demo(name: str) -> dict[str, Any]:
    if name not in DEMOS:
        raise KeyError(f"unknown demo: {name}")
    return deepcopy(DEMOS[name]())


def run_all(output_dir: str | Path | None = None) -> dict[str, Any]:
    results = {name: fn() for name, fn in DEMOS.items()}
    if output_dir is not None:
        out = Path(output_dir)
        out.mkdir(parents=True, exist_ok=True)
        import json
        for name, result in results.items():
            (out/f"{name}.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
            render_dashboard(result, out/f"{name}.html", title=f"DIKWP-SAIL: {name}")
    return results
