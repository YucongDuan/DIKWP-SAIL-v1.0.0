from __future__ import annotations

from copy import deepcopy
from typing import Any

from .core import normalize_packet, packet_digest
from .integrity import digest, utc_now


class AliasRegistry:
    """A deterministic alias-to-DIKWP registry.

    An alias can only be born after a valid packet exists. Alias strings never
    acquire semantic-generative authority; they only point to packet digests.
    """

    def __init__(self) -> None:
        self._revisions: dict[str, list[dict[str, Any]]] = {}
        self._packets: dict[str, dict[str, Any]] = {}

    def register(
        self,
        alias: str,
        packet: Any,
        *,
        actor: str,
        note: str | None = None,
    ) -> dict[str, Any]:
        alias = str(alias).strip()
        actor = str(actor).strip()
        if not alias:
            raise ValueError("alias must be non-empty")
        if not actor:
            raise ValueError("actor must be non-empty")
        normalized = normalize_packet(packet)
        pdigest = packet_digest(normalized)
        previous = self._revisions.get(alias, [])
        revision = {
            "alias": alias,
            "revision": len(previous) + 1,
            "packet_digest": pdigest,
            "previous_packet_digest": previous[-1]["packet_digest"] if previous else None,
            "actor": actor,
            "note": note,
            "registered_at": utc_now(),
            "semantic_authority": 0,
        }
        self._packets[pdigest] = deepcopy(normalized)
        self._revisions.setdefault(alias, []).append(revision)
        return deepcopy(revision)

    def is_registered(self, alias: str) -> bool:
        return str(alias) in self._revisions

    def resolve(self, alias: str, revision: int | None = None) -> dict[str, Any]:
        alias = str(alias)
        rows = self._revisions.get(alias)
        if not rows:
            raise KeyError(f"alias is not registered: {alias}")
        row = rows[-1] if revision is None else rows[revision - 1]
        return deepcopy(self._packets[row["packet_digest"]])

    def record(self, alias: str, revision: int | None = None) -> dict[str, Any]:
        rows = self._revisions.get(str(alias))
        if not rows:
            raise KeyError(f"alias is not registered: {alias}")
        return deepcopy(rows[-1] if revision is None else rows[revision - 1])

    def aliases_for_packet(self, packet: Any) -> list[str]:
        pdigest = packet_digest(packet)
        aliases: list[str] = []
        for alias, rows in self._revisions.items():
            if rows and rows[-1]["packet_digest"] == pdigest:
                aliases.append(alias)
        return sorted(aliases)

    def export(self) -> dict[str, Any]:
        return {
            "semantic_authority": 0,
            "aliases": deepcopy(self._revisions),
            "packet_digests": sorted(self._packets),
            "registry_digest": digest(self._revisions),
        }
