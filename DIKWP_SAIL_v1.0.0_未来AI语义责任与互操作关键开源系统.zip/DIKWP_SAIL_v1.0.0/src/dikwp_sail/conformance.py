from __future__ import annotations

from copy import deepcopy
from typing import Any, Callable

from .adapters import wrap
from .authority import create_grant
from .core import CORE_KINDS, ROUTES, SemanticSpecError, apply_route, empty_packet, normalize_packet
from .demos import full_packet, partial_packet
from .engine import SAILRuntime
from .handoff import create_handoff
from .integrity import make_ledger, verify_ledger
from .passport import create_passport, scaffold_passport, validate_passport
from .receipt import create_receipt, verify_receipt
from .registry import AliasRegistry


def _observed(fn: Callable[[], Any]) -> tuple[str, str | None]:
    try:
        value = fn()
        if value is False:
            return "OPEN", "call returned False"
        return "OBSERVED", None
    except Exception as exc:
        return "OPEN", str(exc)


def run_conformance() -> dict[str, Any]:
    checks: dict[str, dict[str, Any]] = {}

    def add(name: str, fn: Callable[[], Any]) -> None:
        state, detail = _observed(fn)
        checks[name] = {"state": state, "detail": detail}

    add("five_core_kinds_only", lambda: CORE_KINDS == ("D", "I", "K", "W", "P"))
    add("twenty_five_routes", lambda: len(ROUTES) == 25 and len(set(ROUTES)) == 25)
    add("all_false_packet_is_explicit", lambda: normalize_packet(empty_packet()))
    add("missing_kind_stops_before_path", lambda: _expect_semantic_error({"D": {}, "I": {}, "K": {}, "W": {}}))
    add("non_core_kind_stops_before_path", lambda: _expect_semantic_error({**empty_packet(), "X": {}}))
    add("given_false_cannot_carry_content", lambda: _expect_semantic_error({**empty_packet(), "D": {"given": False, "same_semantics": ["x"]}}))
    add("purpose_requires_input_output", lambda: _expect_semantic_error({**empty_packet(), "P": {"given": True, "input": "x", "output": None}}))
    add("source_not_given_keeps_target", lambda: apply_route(empty_packet(), {"from": "D", "to": "I", "target_part": {"given": True, "different_semantics": ["x"]}})[1]["state"] == "OPEN_SOURCE_NOT_GIVEN")
    add("target_not_explicit_keeps_target", lambda: apply_route(full_packet(), {"from": "D", "to": "I"})[1]["state"] == "OPEN_TARGET_NOT_EXPLICIT")
    add("explicit_core_route_generates", lambda: apply_route(full_packet(), {"from": "D", "to": "I", "target_part": {"given": True, "different_semantics": ["new"]}})[1]["state"] == "EXPLICIT_CORE_TO_CORE_GENERATION")
    add("alias_requires_existing_packet", lambda: _registry_roundtrip())
    add("carrier_has_zero_semantic_authority", lambda: scaffold_passport({"text": "x"}, issuer="i", subject="s", carrier_protocol="generic")["carrier"]["semantic_authority"] == 0)
    add("carrier_does_not_infer_packet", lambda: scaffold_passport({"text": "x"}, issuer="i", subject="s", carrier_protocol="generic")["not_given"] == list(CORE_KINDS))
    add("passport_integrity", lambda: validate_passport(create_passport(full_packet(), issuer="i", subject="s", carrier_protocol="generic"))["valid"])
    add("mcp_adapter_preserves_payload", lambda: wrap("mcp", {"jsonrpc": "2.0", "method": "tools/list"}, issuer="i", subject="s", packet=empty_packet())["carrier"]["payload"]["method"] == "tools/list")
    add("a2a_adapter_preserves_payload", lambda: wrap("a2a", {"messageId": "1"}, issuer="i", subject="s", packet=empty_packet())["adapter_view"]["message_id"] == "1")
    add("openai_adapter_preserves_payload", lambda: wrap("openai", {"id": "r1", "output": []}, issuer="i", subject="s", packet=empty_packet())["adapter_view"]["response_id"] == "r1")
    add("generic_adapter_available", lambda: wrap("generic", {"x": 1}, issuer="i", subject="s", packet=empty_packet()))
    add("action_gate_needs_w_p", lambda: _action_gate_open())
    add("action_gate_can_be_ready", lambda: _action_gate_ready())
    add("action_gate_never_executes", lambda: not _runtime_action()["executed"])
    add("memory_gate_requires_retention_scope", lambda: _memory_scope_open())
    add("memory_gate_never_writes", lambda: not _runtime_memory()["written"])
    add("handoff_no_automatic_core_copy", lambda: create_handoff(create_passport(full_packet(), issuer="a", subject="s", carrier_protocol="a2a"), receiver_subject="s", receiver_issuer="b")["copy_policy"] == "NO_AUTOMATIC_CORE_COPY")
    add("handoff_w_p_explicit_only", lambda: create_handoff(create_passport(full_packet(), issuer="a", subject="s", carrier_protocol="a2a"), receiver_subject="s", receiver_issuer="b")["w_p_inheritance"] == "EXPLICIT_ONLY")
    add("ledger_chain_verifies", lambda: verify_ledger(make_ledger([{"x": 1}, {"x": 2}]))["valid"])
    add("receipt_verifies", lambda: _receipt_roundtrip())
    add("receipt_hmac_verifies", lambda: _receipt_hmac_roundtrip())
    add("nonaggregate_gate_vector_present", lambda: isinstance(_runtime_action()["gate"]["vector"], dict))
    add("aggregate_score_absent", lambda: "score" not in str(_runtime_action()).lower())
    add("external_result_semantic_authority_zero", lambda: _runtime_action()["receipt"]["semantic_authority"] == 0)
    add("otel_export_semantic_authority_zero", lambda: _runtime_action()["otel_span"]["semantic_authority"] == 0)
    add("prov_export_semantic_authority_zero", lambda: _runtime_action()["provenance"]["semantic_authority"] == 0)
    add("deterministic_passport_id", lambda: _stable_passport_id())
    add("semantic_digest_independent_of_timestamp", lambda: _stable_semantic_digest())

    all_observed = all(row["state"] == "OBSERVED" for row in checks.values())
    return {
        "spec": "dikwp-sail-conformance/1.0",
        "mode": "MESH80_SEMANTIC_ACCOUNTABILITY_INTEROP_LAYER",
        "checks": checks,
        "all_obligations_observed": all_observed,
        "aggregate_score": None,
        "semantic_authority": 0,
    }


def _expect_semantic_error(packet: Any) -> bool:
    try:
        normalize_packet(packet)
    except SemanticSpecError:
        return True
    return False


def _registry_roundtrip() -> bool:
    reg = AliasRegistry()
    reg.register("invoice", full_packet(), actor="human")
    return reg.resolve("invoice") == normalize_packet(full_packet()) and reg.aliases_for_packet(full_packet()) == ["invoice"]


def _action_gate_open() -> bool:
    runtime = SAILRuntime()
    passport = runtime.wrap("generic", {}, issuer="i", subject="s", packet=partial_packet())
    grant = create_grant(actor="a", subject="s", kinds=["P"], operations=["action.request"])
    result = runtime.prepare_action(passport, {"actor": "a", "subject": "s"}, grants=[grant])
    return result["gate"]["state"] == "OPEN_SEMANTIC_OBLIGATIONS"


def _action_gate_ready() -> bool:
    runtime = SAILRuntime()
    passport = runtime.wrap("generic", {}, issuer="i", subject="s", packet=full_packet())
    grant = create_grant(actor="a", subject="s", kinds=["W", "P"], operations=["action.request"])
    result = runtime.prepare_action(passport, {"actor": "a", "subject": "s"}, grants=[grant])
    return result["gate"]["state"] == "READY_FOR_CALLER_EXECUTION"


def _runtime_action() -> dict[str, Any]:
    runtime = SAILRuntime()
    passport = runtime.wrap("generic", {}, issuer="i", subject="s", packet=full_packet())
    grant = create_grant(actor="a", subject="s", kinds=["W", "P"], operations=["action.request"])
    return runtime.prepare_action(passport, {"actor": "a", "subject": "s"}, grants=[grant])


def _runtime_memory() -> dict[str, Any]:
    runtime = SAILRuntime()
    passport = runtime.wrap("generic", {}, issuer="i", subject="s", packet=full_packet())
    grant = create_grant(actor="a", subject="s", kinds=["P"], operations=["memory.write"])
    return runtime.prepare_memory(passport, {"actor": "a", "subject": "s", "retention_scope": "session"}, grants=[grant])


def _memory_scope_open() -> bool:
    runtime = SAILRuntime()
    passport = runtime.wrap("generic", {}, issuer="i", subject="s", packet=full_packet())
    grant = create_grant(actor="a", subject="s", kinds=["P"], operations=["memory.write"])
    result = runtime.prepare_memory(passport, {"actor": "a", "subject": "s"}, grants=[grant])
    return result["gate"]["state"] == "OPEN_SEMANTIC_OBLIGATIONS"


def _receipt_roundtrip() -> bool:
    run = _runtime_action()
    return verify_receipt(run["receipt"])["valid"]


def _receipt_hmac_roundtrip() -> bool:
    runtime = SAILRuntime()
    passport = runtime.wrap("generic", {}, issuer="i", subject="s", packet=full_packet())
    grant = create_grant(actor="a", subject="s", kinds=["W", "P"], operations=["action.request"])
    run = runtime.prepare_action(passport, {"actor": "a", "subject": "s"}, grants=[grant], secret="local-demo")
    return verify_receipt(run["receipt"], secret="local-demo")["valid"]


def _stable_passport_id() -> bool:
    a = create_passport(full_packet(), issuer="i", subject="s", carrier_protocol="generic", carrier_payload={"x": 1})
    b = create_passport(full_packet(), issuer="i", subject="s", carrier_protocol="generic", carrier_payload={"x": 1})
    return a["passport_id"] == b["passport_id"]


def _stable_semantic_digest() -> bool:
    a = create_passport(full_packet(), issuer="i", subject="s", carrier_protocol="generic")
    b = create_passport(full_packet(), issuer="j", subject="t", carrier_protocol="mcp")
    return a["semantic_digest"] == b["semantic_digest"]
