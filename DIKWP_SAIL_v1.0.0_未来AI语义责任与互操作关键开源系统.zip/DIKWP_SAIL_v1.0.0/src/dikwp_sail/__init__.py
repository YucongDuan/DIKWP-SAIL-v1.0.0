"""DIKWP-SAIL: Semantic Accountability & Interoperability Layer."""

from .adapters import wrap
from .authority import create_grant
from .conformance import run_conformance
from .core import CORE_KINDS, ROUTES, apply_path, apply_route, empty_packet, normalize_packet
from .engine import SAILRuntime
from .gate import gate_action, gate_memory
from .handoff import create_handoff
from .passport import create_passport, scaffold_passport, validate_passport
from .receipt import create_receipt, verify_receipt

__version__ = "1.0.0"

__all__ = [
    "CORE_KINDS", "ROUTES", "SAILRuntime", "apply_path", "apply_route",
    "create_grant", "create_handoff", "create_passport", "create_receipt",
    "empty_packet", "gate_action", "gate_memory", "normalize_packet",
    "run_conformance", "scaffold_passport", "validate_passport", "verify_receipt", "wrap",
]
