from __future__ import annotations

from copy import deepcopy
from typing import Any

from .integrity import digest, hmac_sign, make_ledger, utc_now, verify_ledger


def create_receipt(
    *,
    passport: Any,
    operation_request: Any,
    gate_result: Any,
    external_result: Any = None,
    secret: str | None = None,
) -> dict[str, Any]:
    events = [
        {"type": "passport", "passport_id": passport.get("passport_id"), "semantic_digest": passport.get("semantic_digest")},
        {"type": "operation_request", "request": deepcopy(operation_request)},
        {"type": "gate", "gate": deepcopy(gate_result)},
        {"type": "external_result", "result": deepcopy(external_result), "semantic_authority": 0},
    ]
    ledger = make_ledger(events)
    body = {
        "spec": "dikwp-sail-receipt/1.0",
        "passport_id": passport.get("passport_id"),
        "semantic_digest": passport.get("semantic_digest"),
        "gate_state": gate_result.get("state"),
        "operation_request": deepcopy(operation_request),
        "external_result": deepcopy(external_result),
        "ledger": ledger,
        "semantic_authority": 0,
    }
    receipt = {
        "receipt_id": "receipt_" + digest(body)[:24],
        "created_at": utc_now(),
        **body,
    }
    if secret:
        receipt["hmac_sha256"] = hmac_sign(body, secret)
    return receipt


def verify_receipt(receipt: Any, *, secret: str | None = None) -> dict[str, Any]:
    if not isinstance(receipt, dict):
        return {"valid": False, "errors": ["receipt must be an object"]}
    errors: list[str] = []
    ledger_result = verify_ledger(receipt.get("ledger"))
    if not ledger_result["valid"]:
        errors.append("ledger verification remains open")
    body = {
        key: deepcopy(value)
        for key, value in receipt.items()
        if key not in {"receipt_id", "created_at", "hmac_sha256"}
    }
    if receipt.get("receipt_id") != "receipt_" + digest(body)[:24]:
        errors.append("receipt_id does not match content")
    if secret:
        from .integrity import hmac_verify
        if not hmac_verify(body, secret, str(receipt.get("hmac_sha256", ""))):
            errors.append("HMAC verification remains open")
    return {"valid": not errors, "ledger": ledger_result, "errors": errors}
