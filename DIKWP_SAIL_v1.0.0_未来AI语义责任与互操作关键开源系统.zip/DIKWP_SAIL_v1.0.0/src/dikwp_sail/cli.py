from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from .conformance import run_conformance
from .dashboard import render_dashboard
from .demos import DEMOS, run_all, run_demo
from .engine import SAILRuntime
from .gateway import serve
from .passport import validate_passport
from .receipt import verify_receipt


def _load(path: str) -> Any:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def _dump(value: Any, path: str | None = None) -> None:
    text = json.dumps(value, ensure_ascii=False, indent=2)
    if path:
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        Path(path).write_text(text, encoding="utf-8")
    else:
        print(text)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="dikwp-sail", description="DIKWP semantic accountability and interoperability layer")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("core")
    c = sub.add_parser("conformance"); c.add_argument("--out")
    d = sub.add_parser("demo"); d.add_argument("name", choices=sorted(DEMOS)); d.add_argument("--out"); d.add_argument("--dashboard")
    da = sub.add_parser("demo-all"); da.add_argument("--out-dir", default="outputs/reference")
    w = sub.add_parser("wrap"); w.add_argument("protocol"); w.add_argument("payload"); w.add_argument("--packet"); w.add_argument("--issuer", required=True); w.add_argument("--subject", required=True); w.add_argument("--out")
    vp = sub.add_parser("validate-passport"); vp.add_argument("path")
    vr = sub.add_parser("verify-receipt"); vr.add_argument("path"); vr.add_argument("--secret")
    s = sub.add_parser("serve"); s.add_argument("--host", default="127.0.0.1"); s.add_argument("--port", type=int, default=8780)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.command == "core":
        _dump({
            "mode": "MESH80_SEMANTIC_ACCOUNTABILITY_INTEROP_LAYER",
            "semantic_generators": ["D", "I", "K", "W", "P"],
            "routes": 25,
            "external_protocol_authority": 0,
            "automatic_execution_authority": 0,
        })
    elif args.command == "conformance":
        result = run_conformance(); _dump(result, args.out); return 0 if result["all_obligations_observed"] else 2
    elif args.command == "demo":
        result = run_demo(args.name); _dump(result, args.out)
        if args.dashboard: render_dashboard(result, args.dashboard, title=f"DIKWP-SAIL: {args.name}")
    elif args.command == "demo-all":
        result = run_all(args.out_dir); _dump({"demos": sorted(result), "output_dir": args.out_dir})
    elif args.command == "wrap":
        runtime = SAILRuntime(); payload = _load(args.payload); packet = _load(args.packet) if args.packet else None
        _dump(runtime.wrap(args.protocol, payload, issuer=args.issuer, subject=args.subject, packet=packet), args.out)
    elif args.command == "validate-passport":
        result = validate_passport(_load(args.path)); _dump(result); return 0 if result["valid"] else 2
    elif args.command == "verify-receipt":
        result = verify_receipt(_load(args.path), secret=args.secret); _dump(result); return 0 if result["valid"] else 2
    elif args.command == "serve":
        serve(args.host, args.port)
    return 0
