from __future__ import annotations

from copy import deepcopy
from typing import Any

from .core import CORE_KINDS, empty_packet, normalize_packet, packet_digest, packet_not_given
from .integrity import digest, utc_now

PASSPORT_SPEC = "dikwp-sail-passport/1.0"


def _stable_content(passport: dict[str, Any]) -> dict[str, Any]:
    return {
        key: deepcopy(value)
        for key, value in passport.items()
        if key not in {"passport_id", "created_at", "integrity"}
    }


def create_passport(
    packet: Any,
    *,
    issuer: str,
    subject: str,
    carrier_protocol: str,
    carrier_payload: Any = None,
    aliases: list[str] | None = None,
    route_events: list[dict[str, Any]] | None = None,
    lineage: list[str] | None = None,
    profile: str = "core",
    context: dict[str, Any] | None = None,
) -> dict[str, Any]:
    issuer = str(issuer).strip()
    subject = str(subject).strip()
    carrier_protocol = str(carrier_protocol).strip().lower()
    if not issuer or not subject or not carrier_protocol:
        raise ValueError("issuer, subject, and carrier_protocol must be non-empty")
    normalized = normalize_packet(packet)
    raw_aliases = [str(a).strip() for a in (aliases or [])]
    if any(not a for a in raw_aliases):
        raise ValueError("aliases must be non-empty strings")
    carrier = {
        "protocol": carrier_protocol,
        "payload": deepcopy(carrier_payload),
        "payload_digest": digest(carrier_payload),
        "semantic_authority": 0,
    }
    body: dict[str, Any] = {
        "spec": PASSPORT_SPEC,
        "mode": "MESH80_SEMANTIC_ACCOUNTABILITY_INTEROP_LAYER",
        "issuer": issuer,
        "subject": subject,
        "profile": str(profile),
        "semantic_packet": normalized,
        "semantic_digest": packet_digest(normalized),
        "not_given": packet_not_given(normalized),
        "aliases": raw_aliases,
        "route_events": deepcopy(route_events or []),
        "lineage": list(lineage or []),
        "context": deepcopy(context or {}),
        "carrier": carrier,
        "semantic_authority": {
            "core_kinds": list(CORE_KINDS),
            "carrier": 0,
            "alias": 0,
            "log": 0,
            "timestamp": 0,
            "digest": 0,
        },
    }
    passport_id = "sail_" + digest(body)[:24]
    passport = {
        "passport_id": passport_id,
        "created_at": utc_now(),
        **body,
    }
    passport["integrity"] = {
        "algorithm": "SHA-256",
        "content_digest": digest(_stable_content(passport)),
        "semantic_authority": 0,
    }
    return passport



def refresh_integrity(passport: dict[str, Any]) -> dict[str, Any]:
    """Recompute external identifiers after adding authority-zero adapter views."""
    if not isinstance(passport, dict):
        raise ValueError("passport must be an object")
    passport["passport_id"] = "sail_" + digest(_stable_content(passport))[:24]
    passport["integrity"] = {
        "algorithm": "SHA-256",
        "content_digest": digest(_stable_content(passport)),
        "semantic_authority": 0,
    }
    return passport

def scaffold_passport(
    carrier_payload: Any,
    *,
    issuer: str,
    subject: str,
    carrier_protocol: str,
    aliases: list[str] | None = None,
) -> dict[str, Any]:
    """Wrap a carrier without inventing any DIKWP semantics."""
    return create_passport(
        empty_packet(),
        issuer=issuer,
        subject=subject,
        carrier_protocol=carrier_protocol,
        carrier_payload=carrier_payload,
        aliases=aliases,
        profile="semantic-scaffold",
    )


def validate_passport(raw: Any) -> dict[str, Any]:
    result = {
        "structure": "OPEN",
        "semantic_packet": "OPEN",
        "semantic_digest": "OPEN",
        "integrity": "OPEN",
        "carrier_authority_zero": "OPEN",
        "passport_id": "OPEN",
    }
    errors: list[str] = []
    if not isinstance(raw, dict):
        return {"valid": False, "vector": result, "errors": ["passport must be an object"]}
    required = {
        "passport_id", "created_at", "spec", "mode", "issuer", "subject", "profile",
        "semantic_packet", "semantic_digest", "not_given", "aliases", "route_events",
        "lineage", "context", "carrier", "semantic_authority", "integrity",
    }
    missing = sorted(required - set(raw))
    if missing:
        errors.append(f"missing fields: {missing}")
    else:
        result["structure"] = "OBSERVED"
    try:
        packet = normalize_packet(raw.get("semantic_packet"))
        result["semantic_packet"] = "OBSERVED"
        if packet_digest(packet) == raw.get("semantic_digest"):
            result["semantic_digest"] = "OBSERVED"
        else:
            errors.append("semantic_digest does not match semantic_packet")
    except Exception as exc:
        errors.append(str(exc))
    carrier = raw.get("carrier")
    if isinstance(carrier, dict) and carrier.get("semantic_authority") == 0:
        result["carrier_authority_zero"] = "OBSERVED"
    else:
        errors.append("carrier.semantic_authority must be 0")
    if raw.get("passport_id") == "sail_" + digest({
        key: deepcopy(value)
        for key, value in raw.items()
        if key not in {"passport_id", "created_at", "integrity"}
    })[:24]:
        result["passport_id"] = "OBSERVED"
    else:
        errors.append("passport_id does not match stable content")
    integrity = raw.get("integrity")
    if isinstance(integrity, dict) and integrity.get("content_digest") == digest(_stable_content(raw)):
        result["integrity"] = "OBSERVED"
    else:
        errors.append("integrity content_digest does not match")
    return {
        "valid": not errors,
        "vector": result,
        "errors": errors,
    }
