from __future__ import annotations

from typing import Any

from .base import wrap_carrier
from ..passport import refresh_integrity


def wrap_a2a(payload: Any, **kwargs: Any) -> dict[str, Any]:
    if not isinstance(payload, dict):
        raise ValueError("A2A carrier must be an object")
    passport = wrap_carrier("a2a", payload, profile="a2a-semantic-accountability", **kwargs)
    passport["adapter_view"] = {
        "message_id": payload.get("messageId") or payload.get("id"),
        "task_id": payload.get("taskId") or payload.get("task_id"),
        "role": payload.get("role"),
        "semantic_authority": 0,
    }
    return refresh_integrity(passport)
