from __future__ import annotations

from typing import Any

from .a2a import wrap_a2a
from .generic import wrap_generic
from .mcp import wrap_mcp
from .openai import wrap_openai

ADAPTERS = {
    "mcp": wrap_mcp,
    "a2a": wrap_a2a,
    "openai": wrap_openai,
    "generic": wrap_generic,
    "generic-json": wrap_generic,
}


def wrap(protocol: str, payload: Any, **kwargs: Any) -> dict[str, Any]:
    key = str(protocol).strip().lower()
    if key not in ADAPTERS:
        raise ValueError(f"unsupported adapter: {protocol}; available={sorted(ADAPTERS)}")
    return ADAPTERS[key](payload, **kwargs)


__all__ = ["wrap", "wrap_mcp", "wrap_a2a", "wrap_openai", "wrap_generic"]
