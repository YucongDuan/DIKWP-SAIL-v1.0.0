from __future__ import annotations

from typing import Any

from .base import wrap_carrier


def wrap_generic(payload: Any, **kwargs: Any) -> dict[str, Any]:
    return wrap_carrier("generic-json", payload, profile="generic-semantic-accountability", **kwargs)
