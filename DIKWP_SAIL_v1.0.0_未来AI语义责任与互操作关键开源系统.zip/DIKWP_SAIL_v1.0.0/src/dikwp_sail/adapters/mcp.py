from __future__ import annotations

from typing import Any

from .base import wrap_carrier
from ..passport import refresh_integrity


def wrap_mcp(payload: Any, **kwargs: Any) -> dict[str, Any]:
    if not isinstance(payload, dict):
        raise ValueError("MCP carrier must be an object")
    if payload.get("jsonrpc") not in {None, "2.0"}:
        raise ValueError("MCP JSON-RPC version must be 2.0 when supplied")
    passport = wrap_carrier("mcp", payload, profile="mcp-semantic-accountability", **kwargs)
    passport["adapter_view"] = {
        "method": payload.get("method"),
        "request_id": payload.get("id"),
        "has_params": "params" in payload,
        "semantic_authority": 0,
    }
    return refresh_integrity(passport)
