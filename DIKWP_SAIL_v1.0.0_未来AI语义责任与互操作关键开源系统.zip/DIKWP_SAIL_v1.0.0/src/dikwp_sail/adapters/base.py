from __future__ import annotations

from typing import Any

from ..core import empty_packet
from ..passport import create_passport


def wrap_carrier(
    protocol: str,
    payload: Any,
    *,
    issuer: str,
    subject: str,
    packet: Any | None = None,
    aliases: list[str] | None = None,
    profile: str | None = None,
) -> dict[str, Any]:
    return create_passport(
        packet if packet is not None else empty_packet(),
        issuer=issuer,
        subject=subject,
        carrier_protocol=protocol,
        carrier_payload=payload,
        aliases=aliases,
        profile=profile or f"{protocol}-adapter",
    )
