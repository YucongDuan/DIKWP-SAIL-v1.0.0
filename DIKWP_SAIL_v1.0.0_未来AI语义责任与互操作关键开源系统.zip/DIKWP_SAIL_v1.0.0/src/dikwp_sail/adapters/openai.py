from __future__ import annotations

from typing import Any

from .base import wrap_carrier
from ..passport import refresh_integrity


def wrap_openai(payload: Any, **kwargs: Any) -> dict[str, Any]:
    if not isinstance(payload, dict):
        raise ValueError("OpenAI carrier must be an object")
    passport = wrap_carrier("openai", payload, profile="openai-response-semantic-accountability", **kwargs)
    passport["adapter_view"] = {
        "object": payload.get("object"),
        "response_id": payload.get("id"),
        "model": payload.get("model"),
        "output_types": [
            item.get("type") for item in payload.get("output", []) if isinstance(item, dict)
        ],
        "semantic_authority": 0,
    }
    return refresh_integrity(passport)
