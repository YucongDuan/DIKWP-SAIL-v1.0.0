from __future__ import annotations

import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any

from .conformance import run_conformance
from .engine import SAILRuntime


class _Handler(BaseHTTPRequestHandler):
    runtime = SAILRuntime()

    def _send(self, status: int, payload: Any) -> None:
        raw = json.dumps(payload, ensure_ascii=False, indent=2).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def _read_json(self) -> Any:
        length = int(self.headers.get("Content-Length", "0"))
        raw = self.rfile.read(length) if length else b"{}"
        return json.loads(raw.decode("utf-8"))

    def do_GET(self) -> None:  # noqa: N802
        if self.path == "/health":
            self._send(200, {"service": "dikwp-sail", "state": "READY", "semantic_authority": 0})
        elif self.path == "/v1/conformance":
            self._send(200, run_conformance())
        else:
            self._send(404, {"state": "OPEN_ROUTE", "path": self.path})

    def do_POST(self) -> None:  # noqa: N802
        try:
            body = self._read_json()
            if self.path == "/v1/wrap":
                result = self.runtime.wrap(
                    body["protocol"], body.get("payload"), issuer=body["issuer"],
                    subject=body["subject"], packet=body.get("packet"), aliases=body.get("aliases"),
                )
            elif self.path == "/v1/gate/action":
                result = self.runtime.prepare_action(
                    body["passport"], body["request"], grants=body.get("grants"),
                    profile=body.get("profile", "act"),
                )
            elif self.path == "/v1/gate/memory":
                result = self.runtime.prepare_memory(
                    body["passport"], body["request"], grants=body.get("grants"),
                )
            else:
                self._send(404, {"state": "OPEN_ROUTE", "path": self.path})
                return
            self._send(200, result)
        except Exception as exc:
            self._send(400, {"state": "OPEN_REQUEST", "error": str(exc)})

    def log_message(self, format: str, *args: Any) -> None:
        return


def serve(host: str = "127.0.0.1", port: int = 8780) -> None:
    server = ThreadingHTTPServer((host, int(port)), _Handler)
    print(f"DIKWP-SAIL gateway listening on http://{host}:{port}")
    server.serve_forever()
