from __future__ import annotations

from copy import deepcopy
from typing import Any, Iterable

from .integrity import digest

CORE_KINDS: tuple[str, ...] = ("D", "I", "K", "W", "P")
CONTENT_FIELD: dict[str, str] = {
    "D": "same_semantics",
    "I": "different_semantics",
    "K": "complete_semantics",
    "W": "value_information",
}
ROUTES: tuple[str, ...] = tuple(
    f"{source}2{target}" for source in CORE_KINDS for target in CORE_KINDS
)


class SemanticSpecError(ValueError):
    """Raised when a DIKWP core packet violates the MESH8.0 core contract."""


def _require_kind(kind: str) -> None:
    if kind not in CORE_KINDS:
        raise SemanticSpecError(
            f"semantic kind must be one of {list(CORE_KINDS)}; received {kind!r}"
        )


def empty_part(kind: str) -> dict[str, Any]:
    _require_kind(kind)
    if kind == "P":
        return {"given": False, "input": None, "output": None}
    return {"given": False, CONTENT_FIELD[kind]: []}


def empty_packet() -> dict[str, dict[str, Any]]:
    return {kind: empty_part(kind) for kind in CORE_KINDS}


def _list_content(value: Any, *, path: str) -> list[Any]:
    if value is None:
        return []
    if not isinstance(value, list):
        raise SemanticSpecError(f"{path} must be a list")
    return deepcopy(value)


def normalize_part(kind: str, raw: Any) -> dict[str, Any]:
    _require_kind(kind)
    if raw is None:
        return empty_part(kind)
    if not isinstance(raw, dict):
        raise SemanticSpecError(f"{kind} must be an object")

    if kind == "P":
        allowed = {"given", "input", "output"}
        extra = set(raw) - allowed
        if extra:
            raise SemanticSpecError(f"P contains non-core fields: {sorted(extra)}")
        given = bool(raw.get("given", False))
        input_value = deepcopy(raw.get("input"))
        output_value = deepcopy(raw.get("output"))
        if given and (input_value is None or output_value is None):
            raise SemanticSpecError("P.given=true requires both P.input and P.output")
        if not given and (input_value is not None or output_value is not None):
            raise SemanticSpecError("P.given=false cannot carry input or output")
        return {"given": given, "input": input_value, "output": output_value}

    field = CONTENT_FIELD[kind]
    allowed = {"given", field}
    extra = set(raw) - allowed
    if extra:
        raise SemanticSpecError(f"{kind} contains non-core fields: {sorted(extra)}")
    given = bool(raw.get("given", False))
    content = _list_content(raw.get(field, []), path=f"{kind}.{field}")
    if given and not content:
        raise SemanticSpecError(f"{kind}.given=true requires non-empty {field}")
    if not given and content:
        raise SemanticSpecError(f"{kind}.given=false cannot carry {field}")
    return {"given": given, field: content}


def normalize_packet(raw: Any) -> dict[str, dict[str, Any]]:
    if not isinstance(raw, dict):
        raise SemanticSpecError("semantic packet must be an object")
    extra = set(raw) - set(CORE_KINDS)
    if extra:
        raise SemanticSpecError(
            f"semantic packet contains non-core semantic kinds: {sorted(extra)}"
        )
    missing = set(CORE_KINDS) - set(raw)
    if missing:
        raise SemanticSpecError(
            "semantic packet must explicitly contain D, I, K, W, and P; "
            f"missing: {sorted(missing)}"
        )
    return {kind: normalize_part(kind, raw[kind]) for kind in CORE_KINDS}


def packet_digest(packet: Any) -> str:
    return digest(normalize_packet(packet))


def packet_not_given(packet: Any) -> list[str]:
    normalized = normalize_packet(packet)
    return [kind for kind in CORE_KINDS if not normalized[kind]["given"]]


def packet_complete(packet: Any) -> bool:
    return not packet_not_given(packet)


def packet_core_only(packet: Any) -> bool:
    try:
        normalized = normalize_packet(packet)
    except SemanticSpecError:
        return False
    return tuple(normalized) == CORE_KINDS


def route_id(source: str, target: str) -> str:
    _require_kind(source)
    _require_kind(target)
    return f"{source}2{target}"


def normalize_route_step(raw: Any) -> dict[str, Any]:
    if not isinstance(raw, dict):
        raise SemanticSpecError("route step must be an object")
    allowed = {"from", "to", "target_part"}
    extra = set(raw) - allowed
    if extra:
        raise SemanticSpecError(f"route step contains non-core fields: {sorted(extra)}")
    source = str(raw.get("from", ""))
    target = str(raw.get("to", ""))
    rid = route_id(source, target)
    target_part = raw.get("target_part")
    if target_part is not None:
        target_part = normalize_part(target, target_part)
    return {"from": source, "to": target, "route": rid, "target_part": target_part}


def apply_route(packet: Any, raw_step: Any) -> tuple[dict[str, Any], dict[str, Any]]:
    current = normalize_packet(packet)
    step = normalize_route_step(raw_step)
    source = step["from"]
    target = step["to"]
    before = packet_digest(current)
    event: dict[str, Any] = {
        "route": step["route"],
        "from": source,
        "to": target,
        "source_part": deepcopy(current[source]),
        "target_before": deepcopy(current[target]),
        "packet_before": before,
    }
    if not current[source]["given"]:
        event.update(
            {
                "applied": False,
                "state": "OPEN_SOURCE_NOT_GIVEN",
                "target_after": deepcopy(current[target]),
                "packet_after": before,
            }
        )
        return current, event
    if step["target_part"] is None:
        event.update(
            {
                "applied": False,
                "state": "OPEN_TARGET_NOT_EXPLICIT",
                "target_after": deepcopy(current[target]),
                "packet_after": before,
            }
        )
        return current, event

    updated = deepcopy(current)
    updated[target] = deepcopy(step["target_part"])
    after = packet_digest(updated)
    event.update(
        {
            "applied": True,
            "state": "EXPLICIT_CORE_TO_CORE_GENERATION",
            "target_after": deepcopy(updated[target]),
            "packet_after": after,
        }
    )
    return updated, event


def apply_path(packet: Any, path: Iterable[Any] | None) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    current = normalize_packet(packet)
    events: list[dict[str, Any]] = []
    for index, raw_step in enumerate(list(path or [])):
        current, event = apply_route(current, raw_step)
        events.append({"index": index, **event})
    return current, events


def exact_value_match(left: Any, right: Any) -> bool:
    """Deterministic equality only. No semantic inference is performed."""
    return digest(left) == digest(right)


def list_contains_exact(values: list[Any], expected: list[Any]) -> bool:
    available = {digest(item) for item in values}
    return all(digest(item) in available for item in expected)


def packet_view(packet: Any) -> dict[str, Any]:
    normalized = normalize_packet(packet)
    return {
        "D": deepcopy(normalized["D"]["same_semantics"]),
        "I": deepcopy(normalized["I"]["different_semantics"]),
        "K": deepcopy(normalized["K"]["complete_semantics"]),
        "W": deepcopy(normalized["W"]["value_information"]),
        "P": {
            "input": deepcopy(normalized["P"]["input"]),
            "output": deepcopy(normalized["P"]["output"]),
        },
        "not_given": packet_not_given(normalized),
    }
