from __future__ import annotations

import html
import json
from pathlib import Path
from typing import Any


def render_dashboard(data: Any, output: str | Path, *, title: str = "DIKWP-SAIL Receipt Dashboard") -> Path:
    path = Path(output)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(data, ensure_ascii=False, indent=2)
    escaped = html.escape(payload)
    body = f"""<!doctype html>
<html lang=\"en\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">
<title>{html.escape(title)}</title>
<style>
body{{font-family:Arial,Helvetica,sans-serif;margin:0;background:#f3f5f7;color:#17212b}}
header{{background:#13293d;color:white;padding:28px 6vw}} main{{padding:28px 6vw}}
.card{{background:white;border:1px solid #d7dde3;border-radius:12px;padding:20px;box-shadow:0 5px 18px rgba(0,0,0,.06)}}
pre{{white-space:pre-wrap;word-break:break-word;font-size:13px;line-height:1.45}}
.badge{{display:inline-block;padding:4px 10px;border-radius:20px;background:#e8eef4;margin-right:8px}}
</style></head><body><header><h1>{html.escape(title)}</h1><p>Carrier, digest, log and dashboard fields have semantic authority 0.</p></header>
<main><p><span class=\"badge\">MESH8.0 core</span><span class=\"badge\">D/I/K/W/P</span><span class=\"badge\">No automatic execution</span></p>
<div class=\"card\"><pre>{escaped}</pre></div></main></body></html>"""
    path.write_text(body, encoding="utf-8")
    return path
