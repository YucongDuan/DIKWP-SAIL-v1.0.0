# Security

DIKWP-SAIL is a semantic accountability overlay, not an identity provider or sandbox.

- Do not treat `READY_FOR_CALLER_EXECUTION` as permission to bypass host authorization.
- Verify MCP/A2A endpoints, tool code and model providers independently.
- HMAC is optional local integrity, not public-key identity.
- Do not place secrets in Semantic Passports or receipts.
- Apply least privilege to the gateway and bind it to localhost by default.
- Inspect carrier payloads for injection and data exfiltration risks in the host.
- Report vulnerabilities privately before public disclosure.
