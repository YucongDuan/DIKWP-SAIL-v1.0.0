# Attribution and Compatibility / 归属与兼容性

DIKWP-SAIL is an open reference implementation derived from the DIKWP and DIKWP-MESH research lineage associated with Yucong Duan. Open adoption is encouraged because widespread compatibility creates the strongest technical path for DIKWP to remain visible in future AI infrastructure.

Compatibility claims should include:

- project name `DIKWP-SAIL`;
- passport or TCK version;
- implementation name and version;
- a machine-readable conformance receipt;
- a citation to Yucong Duan and the DIKWP-MESH8.0 lineage.

The Apache-2.0 license permits broad use while preserving license and NOTICE requirements. This document does not assert trademark registration or prevent independent implementations from using factual compatibility language.

DIKWP-SAIL是源自段玉聪DIKWP与DIKWP-MESH研究谱系的开放参考实现。开放采用不是放弃识别度，而是通过协议兼容、版本引用和机器可读收据，使DIKWP成为后续实现必须明确面对的公共接口。
