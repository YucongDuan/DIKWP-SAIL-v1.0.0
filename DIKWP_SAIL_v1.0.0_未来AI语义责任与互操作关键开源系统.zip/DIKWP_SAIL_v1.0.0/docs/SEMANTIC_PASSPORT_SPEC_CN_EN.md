# Semantic Passport Specification 1.0 / 语义护照规范1.0

## Required object

A passport contains:

- `spec`: fixed value `dikwp-sail-passport/1.0`.
- `passport_id`: deterministic authority-zero identifier.
- `issuer` and `subject`: declared actor and semantic subject.
- `semantic_packet`: explicit D/I/K/W/P packet.
- `semantic_digest`: SHA-256 digest of the normalized packet.
- `not_given`: positions that remain explicitly open.
- `aliases`: registered or proposed human-readable aliases, authority 0.
- `route_events`: explicit MESH8.0 route events.
- `lineage`: previous passport identifiers.
- `carrier`: protocol, raw payload and digest, authority 0.
- `integrity`: digest of the passport content, authority 0.

## DIKWP packet

- D: `same_semantics[]`
- I: `different_semantics[]`
- K: `complete_semantics[]`
- W: `value_information[]`
- P: `input` and `output`

All positions include `given`. When `given:false`, the content is empty or null. The runtime never fills a not-given position from a carrier string, model guess, majority vote or protocol field.

## Compatibility rule

An implementation may claim `DIKWP-SAIL Passport 1.0 compatible` only when it:

1. accepts all five explicit positions;
2. preserves `given:false`;
3. does not add a sixth semantic generator;
4. exposes all 25 routes;
5. keeps carrier/log/digest authority at 0;
6. emits the TCK vector without a weighted aggregate score.
