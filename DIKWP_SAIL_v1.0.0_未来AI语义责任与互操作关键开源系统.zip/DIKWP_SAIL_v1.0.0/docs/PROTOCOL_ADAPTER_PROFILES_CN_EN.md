# Protocol Adapter Profiles / 协议适配配置

## MCP profile

The adapter wraps a JSON-RPC-shaped MCP message. `method`, `id`, `params`, resources and tool descriptors remain carrier fields. No tool description becomes W or P automatically. A tool call intended for execution should pass the `act` or `high-impact` gate.

MCP适配器包装JSON-RPC对象。方法、参数、资源和工具描述继续属于载体；工具描述不会自动成为W或P。拟执行的工具调用应经过`act`或`high-impact`责任门。

## A2A profile

The adapter preserves message/task identifiers and role fields. A handoff creates an independent receiver packet. Sender W/P remain sender-local unless the receiver explicitly provides corresponding W/P.

A2A适配器保存消息、任务与角色字段。交接时接收方生成独立语义包；发送方W/P不会自动进入接收方。

## OpenAI-shaped profile

The adapter accepts response-shaped JSON and records response/model/output types as authority-zero views. Model text and function-call arguments do not automatically populate DIKWP positions.

## Generic profile

Any JSON-compatible carrier can be wrapped. With no explicit packet, SAIL produces a semantic scaffold with D/I/K/W/P all set to `given:false`.
