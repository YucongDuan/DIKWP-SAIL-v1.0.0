# DIKWP-SAIL Conformance TCK / 一致性测试套件

The reference TCK contains independent obligations covering:

- five core kinds and 25 routes;
- explicit not-given preservation;
- route preconditions;
- alias-after-packet registration;
- carrier authority 0;
- passport integrity;
- MCP/A2A/OpenAI/generic adapters;
- action and memory gates;
- W/P authority;
- handoff noninheritance;
- receipts, HMAC and replay;
- observability and provenance exports;
- absence of a weighted aggregate score;
- deterministic packet/passport digests.

Run:

```bash
dikwp-sail conformance --out validation/CONFORMANCE.json
python -m unittest discover -s tests -v
```

A conformance vector reports `OBSERVED` or `OPEN` per obligation. `all_obligations_observed` is a conjunction for release automation, not a semantic score and not a certification of external correctness.
