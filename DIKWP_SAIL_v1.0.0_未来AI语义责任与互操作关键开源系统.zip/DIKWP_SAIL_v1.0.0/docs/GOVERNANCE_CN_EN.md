# Open Governance / 开放治理

## Invariants

Changes cannot:

- create a sixth semantic generator;
- infer not-given content from transport fields;
- give logs, signatures, timestamps or scores semantic authority;
- let a sender automatically write receiver W/P;
- convert a gate into automatic execution.

## Extension points

Extensions may add carriers, storage backends, signature suites, UI views and domain profiles. Extensions must declare semantic authority 0 unless they explicitly write through one of the 25 D/I/K/W/P routes with caller-supplied target content.

## Versioning

- Passport/TCK breaking changes require a major version.
- Adapter-only additions may use a minor version.
- Documentation and bug fixes use a patch version.
- A release should archive the source, TCK vector, SBOM and SHA-256 manifest together.
