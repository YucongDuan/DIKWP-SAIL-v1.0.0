# DIKWP-SAIL Architecture / 架构

## 1. Position / 位置

```
Users / Institutions / Policies
              |
         DIKWP-SAIL
  Passport | W/P Gate | Receipt | TCK
       /          |          \
     MCP         A2A       Model APIs
      |            |             |
    Tools        Agents       Models/Memory
```

MCP/A2A/API objects are carriers. SAIL does not redefine their transport semantics. It attaches an explicit DIKWP packet and preserves a carrier digest. The carrier has semantic authority 0.

MCP、A2A和模型API对象是载体。SAIL不重定义其传输语义，而是附加显式DIKWP语义包并保存载体摘要；载体语义生成权为0。

## 2. Runtime flow / 运行流

1. Adapter receives a carrier object.
2. Caller supplies an explicit D/I/K/W/P packet, or receives an all-`given:false` scaffold.
3. Passport binds the packet, carrier digest, issuer, subject, aliases and lineage.
4. Action or memory gate checks required core positions and explicit authority grants.
5. SAIL emits a nonaggregate vector and a receipt. It never executes the operation.
6. Host system may execute separately and may attach the external result to a new receipt.
7. OTLP-shaped attributes and PROV-O-shaped JSON-LD can be exported for observability and provenance.

## 3. Strategic interoperability

SAIL is deliberately an overlay rather than a competing transport. This permits one semantic passport to follow a task through model response, A2A delegation, MCP tool use and memory persistence. The invariant travels while carriers change.

SAIL刻意采用“叠加层”而不是竞争性传输协议，使同一语义护照可以经过模型响应、A2A委派、MCP工具调用和记忆持久化；载体变化时，核心语义义务仍可连续回放。

## 4. Trust boundary / 信任边界

- Hashes prove byte-level continuity, not semantic truth.
- A grant records explicit authority claims; it does not prove legal identity.
- A gate reports declared obligations; it does not perform external authorization.
- A ready state is not an execution result.
- A handoff preserves differences; it does not force agreement.
