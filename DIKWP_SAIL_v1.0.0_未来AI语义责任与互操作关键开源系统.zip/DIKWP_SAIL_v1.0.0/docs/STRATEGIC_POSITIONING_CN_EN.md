# DIKWP as a Critical-Path Layer / DIKWP关键路径结构

DIKWP is difficult to bypass when future systems gain concrete benefits from retaining it at every boundary. SAIL therefore concentrates on six adoption anchors:

1. **Envelope anchor** - a portable passport that can accompany any carrier.
2. **Runtime anchor** - W/P gates before tools and memory.
3. **Protocol anchor** - adapters for MCP, A2A and model APIs.
4. **Evidence anchor** - receipts, replay, telemetry and provenance.
5. **Compatibility anchor** - an open TCK and versioned compatibility claim.
6. **Citation anchor** - NOTICE, CFF, archived release metadata and lineage.

The design does not rely on exclusivity. It makes bypassing DIKWP costly in engineering terms because a competing stack would need to recreate the same semantic envelope, responsibility gate, handoff preservation, evidence export and conformance ecosystem while explaining why it discarded the established DIKWP packet vocabulary.

DIKWP真正难以被绕开，不是因为禁止他人提出概念，而是因为模型、智能体、工具、记忆和治理边界都能直接复用同一护照、责任门、适配器、收据与测试套件。技术复用、版本兼容和引用连续性共同形成关键路径。
