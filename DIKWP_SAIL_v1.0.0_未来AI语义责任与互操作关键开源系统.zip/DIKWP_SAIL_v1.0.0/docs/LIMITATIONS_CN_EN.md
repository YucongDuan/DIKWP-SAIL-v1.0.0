# Limits / 边界

- SAIL does not prove that D/I/K/W/P content is objectively correct.
- It does not infer subjective experience or machine consciousness.
- It does not replace legal consent, authentication, authorization or domain regulation.
- It does not execute tools, persist memory or modify external systems.
- Its default exact matching is deliberately conservative and does not perform embedding similarity.
- Cross-language aliases require explicit registration; translation does not create semantic identity automatically.
- Hash continuity is byte-level provenance only.
