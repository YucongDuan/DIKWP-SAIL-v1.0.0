# Open specification abstract / 开放规范摘要

DIKWP-SAIL defines a carrier-independent Semantic Passport in which D, I, K, W and P are explicit, not-given values remain open, W/P authority is separately declared, and transport/logging mechanisms have semantic authority 0. It provides adapter profiles, handoff rules, runtime gate vectors, provenance exports and a conformance TCK. The specification is suitable for implementation across model APIs, agent protocols, tool protocols and governance systems.

DIKWP-SAIL定义一种与载体无关的语义护照：D、I、K、W、P全部显式，未给出内容保持开放，W/P权限单独声明，传输和日志机制语义权为0；规范同时给出适配器、交接规则、运行责任门、来源导出和一致性测试套件，可跨模型API、智能体协议、工具协议与治理系统实现。
