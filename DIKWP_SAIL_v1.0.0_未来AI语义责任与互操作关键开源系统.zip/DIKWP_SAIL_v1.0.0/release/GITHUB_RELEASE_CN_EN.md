# DIKWP-SAIL v1.0.0

## 中文

DIKWP-SAIL是面向未来模型、智能体、工具、记忆与治理系统的协议中立语义责任层。首版交付语义护照、W/P责任门、MCP/A2A/OpenAI适配器、跨智能体交接保全、链式收据、PROV-O/遥测导出、35项一致性义务以及零依赖本地网关。

建议仓库名：`DIKWP-SAIL`  
标签：`v1.0.0`

## English

DIKWP-SAIL is a protocol-neutral semantic accountability layer for future models, agents, tools, memory and governance systems. v1.0.0 includes Semantic Passports, W/P gates, MCP/A2A/OpenAI-shaped adapters, handoff preservation, receipts, provenance/telemetry exports, a 35-obligation TCK and a dependency-free gateway.
