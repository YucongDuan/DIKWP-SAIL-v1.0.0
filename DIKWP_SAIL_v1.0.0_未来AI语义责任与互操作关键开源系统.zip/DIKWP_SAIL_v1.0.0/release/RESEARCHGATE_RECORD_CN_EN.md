# ResearchGate software record

**Title:** DIKWP-SAIL: Semantic Accountability and Interoperability Layer for Future AI Systems

**Author:** Yucong Duan

**Abstract (EN):** DIKWP-SAIL operationalizes DIKWP-MESH8.0 as a protocol-neutral semantic control plane between models, agents, tools, memory stores and governance systems. It introduces an explicit D/I/K/W/P Semantic Passport, W/P responsibility gates, adapters for MCP, A2A and model-response carriers, non-inheriting handoffs, replayable receipts, provenance and observability exports, and a non-weighted conformance kit. The system is released as an Apache-2.0 reference implementation and does not execute tools or certify external truth.

**摘要（中文）：** DIKWP-SAIL将DIKWP-MESH8.0实现为模型、智能体、工具、记忆与治理系统之间的协议中立语义控制平面，提供显式D/I/K/W/P语义护照、W/P责任门、MCP/A2A/模型响应适配器、非继承性交接、可回放收据、来源与遥测导出以及非加权一致性测试套件。系统采用Apache-2.0开源，不自动执行工具，也不认证外部真理。
