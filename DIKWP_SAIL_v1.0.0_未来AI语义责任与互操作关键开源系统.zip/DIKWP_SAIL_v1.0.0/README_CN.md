# DIKWP-SAIL v1.0.0

**DIKWP Semantic Accountability & Interoperability Layer**  
**DIKWP语义责任与互操作层**

DIKWP-SAIL把DIKWP-MESH8.0的D/I/K/W/P核心语义约束部署到模型、智能体、工具、记忆、工作流和治理系统之间。它不是新的模型接口替代品，而是一个协议中立的语义控制平面：MCP可以继续连接工具，A2A可以继续连接智能体，模型API可以继续承载响应；SAIL为这些载体补上机器可读的语义护照、W/P责任门、跨协议交接、可回放收据和一致性测试。

## 为什么存在

当前AI基础设施已经能传递文本、结构化参数、任务、工具调用和遥测数据，但“这些内容在当前主体与上下文中属于D、I、K、W还是P”“谁有权改变W/P”“行动或记忆写入前还有哪些语义位置未给出”通常没有统一的可执行表达。SAIL将这一缺口实现为可嵌入的公共层。

## MESH8.0核心不变量

- 只有D、I、K、W、P具有语义生成权。
- 每个语义包显式包含五个位置；未知内容使用`given:false`，不能省略或猜补。
- 开放全部5×5=25条有向核心路径；写入目标必须同时具备已给出的源和明确给出的目标。
- 概念别名只能在语义包存在后登记；别名本身的语义生成权为0。
- 协议字段、JSON、时间戳、摘要、日志、收据和遥测只运输与回放，语义生成权为0。

## SAIL提供什么

1. **Semantic Passport**：给每次模型输出、工具请求、智能体消息或记忆写入绑定显式D/I/K/W/P。
2. **W/P Responsibility Gate**：对行动和持久化写入分别检查W、P及其明确授权，不自动执行。
3. **Protocol Adapters**：内置MCP、A2A、OpenAI Responses风格对象和通用JSON适配器。
4. **Handoff Preservation**：发送方、接收方和共享语义包分开保存，W/P不自动继承。
5. **Receipts & Replay**：生成SHA-256链式收据，可选HMAC；完整性机制的语义生成权为0。
6. **Observability & Provenance**：导出`dikwp.sail.*`遥测属性和W3C PROV-O兼容JSON-LD。
7. **Conformance TCK**：35项独立义务，不产生加权总分或“意识/真理”认证。
8. **Local Gateway**：零第三方运行依赖的HTTP网关，可嵌入现有服务。

## 快速运行

```bash
python -m pip install dist/dikwp_sail-1.0.0-py3-none-any.whl
dikwp-sail core
dikwp-sail conformance --out outputs/CONFORMANCE.json
dikwp-sail demo-all --out-dir outputs/reference
dikwp-sail serve --host 127.0.0.1 --port 8780
```

无需安装：

```bash
python dist/DIKWP_SAIL.pyz core
python dist/DIKWP_SAIL.pyz demo mcp_ready --out outputs/mcp_ready.json --dashboard outputs/mcp_ready.html
```

## 最小Python示例

```python
from dikwp_sail import SAILRuntime, create_grant

runtime = SAILRuntime()
passport = runtime.wrap(
    "mcp",
    {"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"calendar.create"}},
    issuer="human:owner",
    subject="calendar:event:1",
    packet={
        "D":{"given":True,"same_semantics":["approved meeting request"]},
        "I":{"given":True,"different_semantics":["attendee=A","time=10:00"]},
        "K":{"given":True,"complete_semantics":["create the approved meeting"]},
        "W":{"given":True,"value_information":["do not add unapproved attendees"]},
        "P":{"given":True,"input":"approved request","output":{"tool":"calendar.create"}},
    },
)
grant = create_grant(
    actor="agent:scheduler", subject="calendar:event:1",
    kinds=["W","P"], operations=["action.request"],
)
prepared = runtime.prepare_action(
    passport,
    {"actor":"agent:scheduler","subject":"calendar:event:1","expected_purpose_output":{"tool":"calendar.create"}},
    grants=[grant],
)
assert prepared["executed"] is False
print(prepared["gate"]["state"])
```

## 目录

- `src/dikwp_sail/`：核心运行时、协议适配器、责任门、收据、网关。
- `schemas/`：机器可读JSON Schema。
- `examples/`：输入、输出和六类参考情境。
- `tests/`：单元与协议测试。
- `docs/`：架构、护照规范、适配配置、一致性与治理材料。
- `dashboard/`：静态参考仪表板。
- `validation/`：测试、Schema、发行物和完整性结果。
- `dist/`：Wheel、单文件PYZ与源码包。
- `release/`：GitHub、ResearchGate、Zenodo发布材料。

## 边界

SAIL不判断现实事实真伪，不替代用户授权，不自动执行工具，不自动写入记忆，不认证意识或主观体验，不将协议字段提升为D/I/K/W/P。`READY_FOR_CALLER_EXECUTION`只表示已声明的语义义务在当前输入中被显式满足；真正的执行仍由宿主系统控制。

代码许可证：Apache-2.0。文档建议按CC BY 4.0引用。参见`NOTICE`与`CITATION.cff`。
