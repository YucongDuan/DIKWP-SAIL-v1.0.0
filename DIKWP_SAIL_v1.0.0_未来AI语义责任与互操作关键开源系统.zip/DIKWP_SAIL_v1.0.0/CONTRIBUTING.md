# Contributing

Contributions are welcome through issues and pull requests. Every change must:

1. retain the five D/I/K/W/P core kinds;
2. include tests;
3. keep external carrier fields at semantic authority 0;
4. preserve not-given positions;
5. update schemas and documentation when public objects change;
6. pass `python -m unittest discover -s tests -v` and `dikwp-sail conformance`.
