# Code of Conduct

Participants should communicate respectfully, document disagreements precisely, preserve attribution, distinguish evidence from inference, and avoid personal attacks or coercive behavior. Maintainers may limit participation that persistently disrupts technical collaboration.
